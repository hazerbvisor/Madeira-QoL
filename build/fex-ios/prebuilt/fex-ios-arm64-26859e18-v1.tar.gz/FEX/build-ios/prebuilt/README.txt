Seven FEX libraries cross-compiled from the pinned source for ARM64 iOS 17.0.
These are build inputs, not a completed Madeira app. Final Xcode link and runtime
validation remain pending. Corresponding source is available in this repository
at the pinned FEX submodule revision and recursive dependencies. Initialize with:
  git submodule update --init --recursive FEX
The parent build recipe, compatibility headers and materialization script are
in build/fex-ios/. See build/fex-ios/prebuilt/README.md for provenance and rebuild
instructions. Original copyright and license notices are in prebuilt/licenses.
No Apple SDK or private runtime binaries are included.
